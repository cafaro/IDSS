/* A Bison parser, made by GNU Bison 2.5.  */

/* Bison interface for Yacc-like parsers in C

      Copyright (C) 1984, 1989-1990, 2000-2011 Free Software Foundation, Inc.

   This program is free software: you can redistribute it and/or modify
   it under the terms of the GNU General Public License as published by
   the Free Software Foundation, either version 3 of the License, or
   (at your option) any later version.

   This program is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   GNU General Public License for more details.

   You should have received a copy of the GNU General Public License
   along with this program.  If not, see <http://www.gnu.org/licenses/>.  */

/* As a special exception, you may create a larger work that contains
   part or all of the Bison parser skeleton and distribute that work
   under terms of your choice, so long as that work isn't itself a
   parser generator using the skeleton or a modified version thereof
   as a parser skeleton.  Alternatively, if you modify or redistribute
   the parser skeleton itself, you may (at your option) remove this
   special exception, which will cause the skeleton and the resulting
   Bison output files to be licensed under the GNU General Public
   License without this special exception.

   This special exception was added by the Free Software Foundation in
   version 2.2 of Bison.  */


/* Tokens.  */
#ifndef YYTOKENTYPE
# define YYTOKENTYPE
   /* Put the tokens into the symbol table, so that GDB and other debuggers
      know about them.  */
   enum yytokentype {
     SELECT = 258,
     FROM = 259,
     WHERE = 260,
     NAME = 261,
     COMMA = 262,
     SPACE = 263,
     ALIAS = 264,
     DOT = 265,
     OR = 266,
     AND = 267,
     OP = 268,
     CP = 269,
     EOL = 270,
     SEMICOLON = 271,
     NUMBER = 272,
     BOOL = 273,
     EQ = 274,
     GT = 275,
     LT = 276,
     GTE = 277,
     LTE = 278,
     NE = 279,
     ASTERISK = 280,
     UNKNOWN = 281,
     STRING = 282,
     JOIN = 283,
     ON = 284,
     AGGF = 285,
     NOT = 286,
     IN = 287
   };
#endif
/* Tokens.  */
#define SELECT 258
#define FROM 259
#define WHERE 260
#define NAME 261
#define COMMA 262
#define SPACE 263
#define ALIAS 264
#define DOT 265
#define OR 266
#define AND 267
#define OP 268
#define CP 269
#define EOL 270
#define SEMICOLON 271
#define NUMBER 272
#define BOOL 273
#define EQ 274
#define GT 275
#define LT 276
#define GTE 277
#define LTE 278
#define NE 279
#define ASTERISK 280
#define UNKNOWN 281
#define STRING 282
#define JOIN 283
#define ON 284
#define AGGF 285
#define NOT 286
#define IN 287




#if ! defined YYSTYPE && ! defined YYSTYPE_IS_DECLARED

# define yystype YYSTYPE /* obsolescent; will be withdrawn */
# define YYSTYPE_IS_DECLARED 1
#endif




