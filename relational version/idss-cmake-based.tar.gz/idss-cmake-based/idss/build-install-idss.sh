#! /bin/bash

rm -fr build;

cmake -S . -B build -DCMAKE_BUILD_TYPE="Release" -D CMAKE_C_COMPILER=clang -D CMAKE_CXX_COMPILER=clang++ -DCMAKE_INSTALL_PREFIX="/home/cafaro/idss-cmake-based/simulation/idss-1";
cmake --build build -v;
cmake --install build -v;
