/** @file idss-webservice-lookup-client
 * Lookups an existing web service.
 *
 * To run
 *       ./idss-webservice-lookup-client <options>
 *
 * Copyright 2022-2023 University of Salento, Italy.
 * All rights reserved.
 *
 */
 
//#include "config.h"
#include <unistd.h>
#include "idssH.h"
#include <stdio.h>
#include <syslog.h>
#include "idss_client.h"

extern char *optarg;


static void usage (char *name)
{
  printf ("%s: Usage:\n", name);
  printf ("\t-s web service name: name of the web service you" \
          " want to lookup\n");
  printf ("\t-n hostname: name of the host that provides the web service you want to lookup\n");
  printf ("\t-h web_service_hostname: FQDN of the server hosting the" \
          " iDSS web service\n");
  printf ("\t-p web_service_port: port number where the iDSS web" \
          " service is listening on\n");
  printf ("\t-v : verbose mode\n");
  printf ("\t-u : usage \n");
}

int main (int argc, char **argv)
{
  struct soap          soap;
  xsd__string         result;
  char                 *service;
  char                 *hostname;
  char                 *web_service;
  char                 contact_string[256];
  unsigned short int   port;
  int                  verbose;
  int                  i, j;
  idss_ws_data*  ws_data;

  /* Setting default values */
  service = NULL;
  hostname = NULL;
  port = IDSS_SERVICE_LISTENING_PORT;
  web_service = strdup (IDSS_SERVICE_HOSTNAME);
  verbose = 0;
  
  while ((j = getopt (argc, argv, "h:p:s:n:vu")) > 0)
  {
    switch (j)
    {
      case 'h':
        free (web_service);
        web_service = strdup (optarg);
        break;
      case 'p':
        port = atoi (optarg);
        break;
      case 's':
        service = strdup (optarg);
        break;
      case 'n':
        hostname = strdup (optarg);
        break;
      case 'v':
        verbose = 1;
        break;
      case 'u':
      default:
        usage (argv[0]);
        exit (1);
    }
  }
  
  soap_init(&soap);
  
  sprintf (contact_string, "http://%s:%d", web_service, port);
  contact_string[strlen(contact_string)] = '\0';

  if (verbose)
  {
    printf ("Contacting the web service listening on... %s\n",
            contact_string);
    if (service)
    {
      printf ("Looking up web service... %s\n", service);
    }
    else
    {
      printf ("Looking up any web service available\n");
    }
  }
  
  /*
   * soap_call_idss__lookup_webservice
   * 
   * to search information about a web service. It contacts
   * the supplied iDSS server on the default port
   * 
   * service: the name of the webservice to be searched
   * result: query result
   */
  if (soap_call_idss__lookup_webservice(&soap, contact_string, "", 
              service, hostname, &result))
  {
    soap_print_fault (&soap, stderr);
  }
  else if(result) 
  {
    save_dime_data(result, "webservice.xml");
  
	ws_data = idss_get_ws_data(result);
	
   if(ws_data)
   {
    for (i = 0; ws_data[i]; i++)
    {
      printf("service name = %s\n",ws_data[i]->name);
      printf("description  = %s\n",ws_data[i]->description);
      printf("keywords     = %s\n",ws_data[i]->keywords);
      printf("wsdl_locations\n");
      for (j = 0; ws_data[i]->wsdl_location[j]; j++)
	    printf("\t%s\n",ws_data[i]->wsdl_location[j]);
	  for (j = 0; ws_data[i]->acurl[j]; j++)
	  {
        printf("access URLs #%d\n", j+1);
	    printf("\thostname  = %s\n", ws_data[i]->acurl[j]->hostname);
	    printf("\turl       = %s\n", ws_data[i]->acurl[j]->url);
	    printf("\tpublisher = %s\n", ws_data[i]->acurl[j]->publisher);
	    printf("\tcreated   = %lu\n", ws_data[i]->acurl[j]->cd);
	    printf("\tvalid     = %d\n", ws_data[i]->acurl[j]->vt);
	  }
	  printf("\n");
     }
    }
    idss_delete_ws_data(ws_data);
  }
  
  
  if(web_service)
   free(web_service);
  
  if(service)
   free(service);
   
  if(hostname)
   free(hostname);

  soap_end (&soap);
  soap_done (&soap);
  
  return 0;
}


struct Namespace namespaces[] = {
  {"SOAP-ENV", "http://schemas.xmlsoap.org/soap/envelope/"},
  {"SOAP-ENC", "http://schemas.xmlsoap.org/soap/encoding/"},
  {"xsi", "http://www.w3.org/1999/XMLSchema-instance"},
  {"xsd", "http://www.w3.org/1999/XMLSchema"},
  {"idss", "urn:idss"},
  {NULL, NULL}
};
