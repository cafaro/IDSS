/* parse SQL SELECT statements scanning a NULL terminated string
 *
 * input parameters:
 * 
 * const char *str      The string to be parsed
 * 
 * returns: 0 on success, -1 on error
 *
 * 
 *
 */

int idss_parse(char *str);
